# TVHome MFTR0 V13.2 public install kit

This is the sanitized public delivery for the TVHome MFTR0 V13.2 build.

Included:

- `TVHome-MFTR0-1.0.0-v13.2.apk` — signed APK;
- `release-manifest.json` — strict package, hash, certificate and SDK contract;
- PowerShell/CMD deployment, restore, wallpaper and content-policy scripts.

The package does not contain the private Rain city MPKG, the private wallpaper PNG, device screenshots, ADB addresses, device logs, signing material or user data. The verified device fallback is the supplied static Rain city 4K PNG; dynamic scene-to-video export was not evidenced and is not claimed by this release.

## Install

1. Put this directory on the Windows machine with ADB available.
2. Enable and authorize ADB on the TV, then obtain the TV's current ADB serial/address yourself.
3. Run PowerShell with `-Serial <your-authorized-serial>` and, if needed, `-AdbPath <path-to-adb.exe>`:

```powershell
.\Install-TVHome.ps1 -Serial '<your-authorized-serial>' -AdbPath 'adb'
```

The installer validates the manifest, APK hash, trusted certificate, model and original Xiaomi HOME before any install mutation. It does not set TVHome as the system HOME resolver unless `-ActivateHome` is explicitly supplied.

The content-policy script is optional and reversible. Review its audit output before applying it:

```powershell
.\Apply-ContentPolicy.ps1 -Serial '<your-authorized-serial>' -AdbPath 'adb'
```

To restore the saved package states:

```powershell
.\Restore-ContentPolicy.ps1 -Serial '<your-authorized-serial>' -AdbPath 'adb' -SnapshotPath '<snapshot-json>'
```

The original Xiaomi HOME remains protected and available. Dynamic Rain city, physical Home gesture timing, boot/standby lifecycle and vendor preview behavior require human/device acceptance on the target TV.
